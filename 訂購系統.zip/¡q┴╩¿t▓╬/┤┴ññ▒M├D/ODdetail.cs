﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 期中專題
{
    class ODdetail
    {
        public Panel detail = new Panel();
        public TextBox product = new TextBox();
        public TextBox proqty = new TextBox();
        public TextBox sum = new TextBox();
        public TextBox price = new TextBox();
        public Button DEL = new Button();
        public Button SLT = new Button();
    }
}
