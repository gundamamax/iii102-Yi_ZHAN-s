﻿namespace 期中專題
{
    partial class ORDERSYSTEM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LBORDER = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.RBOUTNO = new System.Windows.Forms.RadioButton();
            this.RBOUTAr = new System.Windows.Forms.RadioButton();
            this.RBOUTALL = new System.Windows.Forms.RadioButton();
            this.dts = new System.Windows.Forms.DateTimePicker();
            this.dtl = new System.Windows.Forms.DateTimePicker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.CBD = new System.Windows.Forms.CheckBox();
            this.selectout = new System.Windows.Forms.RadioButton();
            this.selectord = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rbpayno = new System.Windows.Forms.RadioButton();
            this.Rbpayar = new System.Windows.Forms.RadioButton();
            this.Rbpayall = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BTNSEARCH = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lastcrrect = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.CHEKPAY = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.CHEKOUT = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.AdressDfl = new System.Windows.Forms.Button();
            this.TelDfl = new System.Windows.Forms.Button();
            this.CellDfl = new System.Windows.Forms.Button();
            this.TBCELL = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.TBADRESS = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.TBNAME = new System.Windows.Forms.TextBox();
            this.TBTOTOL = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.DATAOUT = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.TBPHONE = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TBORDERDATE = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.CusSTL = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TBID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.DELITEM = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.SUMCHANGE = new System.Windows.Forms.TextBox();
            this.PRODUCTSTL = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.AMTCHANGE = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.NEW = new System.Windows.Forms.Button();
            this.SAVE = new System.Windows.Forms.Button();
            this.DELETE = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.NEWDETL = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LBORDER
            // 
            this.LBORDER.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LBORDER.FormattingEnabled = true;
            this.LBORDER.ItemHeight = 24;
            this.LBORDER.Location = new System.Drawing.Point(12, 37);
            this.LBORDER.Name = "LBORDER";
            this.LBORDER.Size = new System.Drawing.Size(226, 460);
            this.LBORDER.TabIndex = 0;
            this.LBORDER.SelectedIndexChanged += new System.EventHandler(this.LBORDER_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this.RBOUTNO);
            this.panel1.Controls.Add(this.RBOUTAr);
            this.panel1.Controls.Add(this.RBOUTALL);
            this.panel1.Location = new System.Drawing.Point(3, 61);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(90, 107);
            this.panel1.TabIndex = 1;
            // 
            // RBOUTNO
            // 
            this.RBOUTNO.AutoSize = true;
            this.RBOUTNO.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RBOUTNO.Location = new System.Drawing.Point(3, 71);
            this.RBOUTNO.Name = "RBOUTNO";
            this.RBOUTNO.Size = new System.Drawing.Size(85, 28);
            this.RBOUTNO.TabIndex = 2;
            this.RBOUTNO.TabStop = true;
            this.RBOUTNO.Text = "未出貨";
            this.RBOUTNO.UseVisualStyleBackColor = true;
            // 
            // RBOUTAr
            // 
            this.RBOUTAr.AutoSize = true;
            this.RBOUTAr.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RBOUTAr.Location = new System.Drawing.Point(3, 37);
            this.RBOUTAr.Name = "RBOUTAr";
            this.RBOUTAr.Size = new System.Drawing.Size(85, 28);
            this.RBOUTAr.TabIndex = 1;
            this.RBOUTAr.TabStop = true;
            this.RBOUTAr.Text = "已出貨";
            this.RBOUTAr.UseVisualStyleBackColor = true;
            // 
            // RBOUTALL
            // 
            this.RBOUTALL.AutoSize = true;
            this.RBOUTALL.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.RBOUTALL.Location = new System.Drawing.Point(3, 3);
            this.RBOUTALL.Name = "RBOUTALL";
            this.RBOUTALL.Size = new System.Drawing.Size(66, 28);
            this.RBOUTALL.TabIndex = 0;
            this.RBOUTALL.TabStop = true;
            this.RBOUTALL.Text = "全部";
            this.RBOUTALL.UseVisualStyleBackColor = true;
            // 
            // dts
            // 
            this.dts.Location = new System.Drawing.Point(3, 71);
            this.dts.Name = "dts";
            this.dts.Size = new System.Drawing.Size(198, 35);
            this.dts.TabIndex = 2;
            this.dts.Value = new System.DateTime(2018, 6, 13, 14, 35, 32, 0);
            // 
            // dtl
            // 
            this.dtl.Location = new System.Drawing.Point(3, 112);
            this.dtl.Name = "dtl";
            this.dtl.Size = new System.Drawing.Size(198, 35);
            this.dtl.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel2.Controls.Add(this.CBD);
            this.panel2.Controls.Add(this.selectout);
            this.panel2.Controls.Add(this.selectord);
            this.panel2.Controls.Add(this.dts);
            this.panel2.Controls.Add(this.dtl);
            this.panel2.Location = new System.Drawing.Point(3, 174);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(207, 151);
            this.panel2.TabIndex = 3;
            // 
            // CBD
            // 
            this.CBD.AutoSize = true;
            this.CBD.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.CBD.Location = new System.Drawing.Point(3, 3);
            this.CBD.Name = "CBD";
            this.CBD.Size = new System.Drawing.Size(115, 30);
            this.CBD.TabIndex = 4;
            this.CBD.Text = "範圍搜尋";
            this.CBD.UseVisualStyleBackColor = true;
            // 
            // selectout
            // 
            this.selectout.AutoSize = true;
            this.selectout.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.selectout.Location = new System.Drawing.Point(100, 37);
            this.selectout.Name = "selectout";
            this.selectout.Size = new System.Drawing.Size(104, 28);
            this.selectout.TabIndex = 1;
            this.selectout.TabStop = true;
            this.selectout.Text = "出貨日期";
            this.selectout.UseVisualStyleBackColor = true;
            // 
            // selectord
            // 
            this.selectord.AutoSize = true;
            this.selectord.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.selectord.Location = new System.Drawing.Point(3, 37);
            this.selectord.Name = "selectord";
            this.selectord.Size = new System.Drawing.Size(104, 28);
            this.selectord.TabIndex = 0;
            this.selectord.TabStop = true;
            this.selectord.Text = "下單日期";
            this.selectord.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel3.Controls.Add(this.rbpayno);
            this.panel3.Controls.Add(this.Rbpayar);
            this.panel3.Controls.Add(this.Rbpayall);
            this.panel3.Location = new System.Drawing.Point(116, 61);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(94, 107);
            this.panel3.TabIndex = 3;
            // 
            // rbpayno
            // 
            this.rbpayno.AutoSize = true;
            this.rbpayno.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.rbpayno.Location = new System.Drawing.Point(3, 71);
            this.rbpayno.Name = "rbpayno";
            this.rbpayno.Size = new System.Drawing.Size(85, 28);
            this.rbpayno.TabIndex = 2;
            this.rbpayno.TabStop = true;
            this.rbpayno.Text = "未付款";
            this.rbpayno.UseVisualStyleBackColor = true;
            // 
            // Rbpayar
            // 
            this.Rbpayar.AutoSize = true;
            this.Rbpayar.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Rbpayar.Location = new System.Drawing.Point(3, 37);
            this.Rbpayar.Name = "Rbpayar";
            this.Rbpayar.Size = new System.Drawing.Size(85, 28);
            this.Rbpayar.TabIndex = 1;
            this.Rbpayar.TabStop = true;
            this.Rbpayar.Text = "已付款";
            this.Rbpayar.UseVisualStyleBackColor = true;
            // 
            // Rbpayall
            // 
            this.Rbpayall.AutoSize = true;
            this.Rbpayall.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Rbpayall.Location = new System.Drawing.Point(3, 3);
            this.Rbpayall.Name = "Rbpayall";
            this.Rbpayall.Size = new System.Drawing.Size(66, 28);
            this.Rbpayall.TabIndex = 0;
            this.Rbpayall.TabStop = true;
            this.Rbpayall.Text = "全部";
            this.Rbpayall.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(12, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 31);
            this.label1.TabIndex = 5;
            this.label1.Text = "訂單編號";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(-4, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 31);
            this.label2.TabIndex = 6;
            this.label2.Text = "出貨狀態";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(109, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 31);
            this.label3.TabIndex = 7;
            this.label3.Text = "付款狀態";
            // 
            // BTNSEARCH
            // 
            this.BTNSEARCH.BackColor = System.Drawing.SystemColors.MenuBar;
            this.BTNSEARCH.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BTNSEARCH.Location = new System.Drawing.Point(3, 330);
            this.BTNSEARCH.Name = "BTNSEARCH";
            this.BTNSEARCH.Size = new System.Drawing.Size(207, 41);
            this.BTNSEARCH.TabIndex = 8;
            this.BTNSEARCH.Text = "搜尋";
            this.BTNSEARCH.UseVisualStyleBackColor = false;
            this.BTNSEARCH.Click += new System.EventHandler(this.BTNSEARCH_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.Controls.Add(this.lastcrrect);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.AdressDfl);
            this.panel4.Controls.Add(this.TelDfl);
            this.panel4.Controls.Add(this.CellDfl);
            this.panel4.Controls.Add(this.TBCELL);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.TBADRESS);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.TBNAME);
            this.panel4.Controls.Add(this.TBTOTOL);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.DATAOUT);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.TBPHONE);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.TBORDERDATE);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.CusSTL);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.TBID);
            this.panel4.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel4.Location = new System.Drawing.Point(293, 37);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(921, 309);
            this.panel4.TabIndex = 9;
            // 
            // lastcrrect
            // 
            this.lastcrrect.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lastcrrect.Location = new System.Drawing.Point(663, 270);
            this.lastcrrect.Name = "lastcrrect";
            this.lastcrrect.ReadOnly = true;
            this.lastcrrect.Size = new System.Drawing.Size(255, 35);
            this.lastcrrect.TabIndex = 41;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label20.Location = new System.Drawing.Point(519, 279);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(138, 26);
            this.label20.TabIndex = 40;
            this.label20.Text = "最後修改日期";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.CHEKPAY);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Location = new System.Drawing.Point(230, 251);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(223, 44);
            this.panel6.TabIndex = 39;
            // 
            // CHEKPAY
            // 
            this.CHEKPAY.AutoSize = true;
            this.CHEKPAY.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.CHEKPAY.Location = new System.Drawing.Point(106, 6);
            this.CHEKPAY.Name = "CHEKPAY";
            this.CHEKPAY.Size = new System.Drawing.Size(86, 28);
            this.CHEKPAY.TabIndex = 24;
            this.CHEKPAY.Text = "已付款";
            this.CHEKPAY.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(3, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 31);
            this.label9.TabIndex = 22;
            this.label9.Text = "付款狀態";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.CHEKOUT);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Location = new System.Drawing.Point(9, 251);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(209, 44);
            this.panel5.TabIndex = 38;
            // 
            // CHEKOUT
            // 
            this.CHEKOUT.AutoSize = true;
            this.CHEKOUT.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.CHEKOUT.Location = new System.Drawing.Point(110, 6);
            this.CHEKOUT.Name = "CHEKOUT";
            this.CHEKOUT.Size = new System.Drawing.Size(86, 28);
            this.CHEKOUT.TabIndex = 23;
            this.CHEKOUT.Text = "已出貨";
            this.CHEKOUT.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(3, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 31);
            this.label10.TabIndex = 22;
            this.label10.Text = "出貨狀態";
            // 
            // AdressDfl
            // 
            this.AdressDfl.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.AdressDfl.Location = new System.Drawing.Point(859, 103);
            this.AdressDfl.Name = "AdressDfl";
            this.AdressDfl.Size = new System.Drawing.Size(59, 81);
            this.AdressDfl.TabIndex = 37;
            this.AdressDfl.Text = "預設";
            this.AdressDfl.UseVisualStyleBackColor = true;
            this.AdressDfl.Click += new System.EventHandler(this.AdressDfl_Click);
            // 
            // TelDfl
            // 
            this.TelDfl.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TelDfl.Location = new System.Drawing.Point(859, 4);
            this.TelDfl.Name = "TelDfl";
            this.TelDfl.Size = new System.Drawing.Size(59, 39);
            this.TelDfl.TabIndex = 35;
            this.TelDfl.Text = "預設";
            this.TelDfl.UseVisualStyleBackColor = true;
            this.TelDfl.Click += new System.EventHandler(this.TelDfl_Click);
            // 
            // CellDfl
            // 
            this.CellDfl.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.CellDfl.Location = new System.Drawing.Point(859, 52);
            this.CellDfl.Name = "CellDfl";
            this.CellDfl.Size = new System.Drawing.Size(59, 39);
            this.CellDfl.TabIndex = 36;
            this.CellDfl.Text = "預設";
            this.CellDfl.UseVisualStyleBackColor = true;
            this.CellDfl.Click += new System.EventHandler(this.CellDfl_Click);
            // 
            // TBCELL
            // 
            this.TBCELL.Location = new System.Drawing.Point(456, 52);
            this.TBCELL.MaxLength = 100;
            this.TBCELL.Name = "TBCELL";
            this.TBCELL.Size = new System.Drawing.Size(397, 39);
            this.TBCELL.TabIndex = 34;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label19.Location = new System.Drawing.Point(388, 55);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(62, 31);
            this.label19.TabIndex = 33;
            this.label19.Text = "手機";
            // 
            // TBADRESS
            // 
            this.TBADRESS.Location = new System.Drawing.Point(456, 102);
            this.TBADRESS.MaxLength = 100;
            this.TBADRESS.Multiline = true;
            this.TBADRESS.Name = "TBADRESS";
            this.TBADRESS.Size = new System.Drawing.Size(397, 82);
            this.TBADRESS.TabIndex = 32;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label17.Location = new System.Drawing.Point(388, 105);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(62, 62);
            this.label17.TabIndex = 31;
            this.label17.Text = "送貨\r\n地址";
            // 
            // TBNAME
            // 
            this.TBNAME.Location = new System.Drawing.Point(119, 51);
            this.TBNAME.Name = "TBNAME";
            this.TBNAME.ReadOnly = true;
            this.TBNAME.Size = new System.Drawing.Size(155, 39);
            this.TBNAME.TabIndex = 28;
            // 
            // TBTOTOL
            // 
            this.TBTOTOL.Location = new System.Drawing.Point(119, 204);
            this.TBTOTOL.Name = "TBTOTOL";
            this.TBTOTOL.ReadOnly = true;
            this.TBTOTOL.Size = new System.Drawing.Size(255, 39);
            this.TBTOTOL.TabIndex = 27;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(3, 212);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 31);
            this.label12.TabIndex = 26;
            this.label12.Text = "總價";
            // 
            // DATAOUT
            // 
            this.DATAOUT.Location = new System.Drawing.Point(119, 155);
            this.DATAOUT.Name = "DATAOUT";
            this.DATAOUT.Size = new System.Drawing.Size(255, 39);
            this.DATAOUT.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(3, 161);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(110, 31);
            this.label11.TabIndex = 24;
            this.label11.Text = "出貨日期";
            // 
            // TBPHONE
            // 
            this.TBPHONE.Location = new System.Drawing.Point(456, 5);
            this.TBPHONE.MaxLength = 100;
            this.TBPHONE.Name = "TBPHONE";
            this.TBPHONE.Size = new System.Drawing.Size(397, 39);
            this.TBPHONE.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(388, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 31);
            this.label8.TabIndex = 18;
            this.label8.Text = "電話";
            // 
            // TBORDERDATE
            // 
            this.TBORDERDATE.Location = new System.Drawing.Point(119, 102);
            this.TBORDERDATE.Name = "TBORDERDATE";
            this.TBORDERDATE.ReadOnly = true;
            this.TBORDERDATE.Size = new System.Drawing.Size(255, 39);
            this.TBORDERDATE.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(3, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 31);
            this.label7.TabIndex = 16;
            this.label7.Text = "下單日期";
            // 
            // CusSTL
            // 
            this.CusSTL.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.CusSTL.Location = new System.Drawing.Point(280, 51);
            this.CusSTL.Name = "CusSTL";
            this.CusSTL.Size = new System.Drawing.Size(94, 39);
            this.CusSTL.TabIndex = 13;
            this.CusSTL.Text = "選擇";
            this.CusSTL.UseVisualStyleBackColor = true;
            this.CusSTL.Click += new System.EventHandler(this.CusSTL_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(3, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 31);
            this.label5.TabIndex = 12;
            this.label5.Text = "客戶姓名";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(3, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 31);
            this.label4.TabIndex = 10;
            this.label4.Text = "訂單編號";
            // 
            // TBID
            // 
            this.TBID.Location = new System.Drawing.Point(119, 0);
            this.TBID.Name = "TBID";
            this.TBID.ReadOnly = true;
            this.TBID.Size = new System.Drawing.Size(155, 39);
            this.TBID.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(287, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 31);
            this.label6.TabIndex = 10;
            this.label6.Text = "訂單";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.LightGray;
            this.flowLayoutPanel1.Controls.Add(this.panel7);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(294, 391);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(920, 586);
            this.flowLayoutPanel1.TabIndex = 11;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel7.Controls.Add(this.label21);
            this.panel7.Controls.Add(this.textBox1);
            this.panel7.Controls.Add(this.DELITEM);
            this.panel7.Controls.Add(this.label18);
            this.panel7.Controls.Add(this.SUMCHANGE);
            this.panel7.Controls.Add(this.PRODUCTSTL);
            this.panel7.Controls.Add(this.label16);
            this.panel7.Controls.Add(this.AMTCHANGE);
            this.panel7.Controls.Add(this.label15);
            this.panel7.Controls.Add(this.textBox6);
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(887, 115);
            this.panel7.TabIndex = 0;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label21.Location = new System.Drawing.Point(530, 11);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(69, 35);
            this.label21.TabIndex = 22;
            this.label21.Text = "單價";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox1.Location = new System.Drawing.Point(605, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(264, 50);
            this.textBox1.TabIndex = 21;
            // 
            // DELITEM
            // 
            this.DELITEM.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.DELITEM.Location = new System.Drawing.Point(3, 5);
            this.DELITEM.Name = "DELITEM";
            this.DELITEM.Size = new System.Drawing.Size(34, 104);
            this.DELITEM.TabIndex = 20;
            this.DELITEM.Text = "刪除項目";
            this.DELITEM.UseVisualStyleBackColor = true;
            this.DELITEM.Click += new System.EventHandler(this.DELITEM_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.Location = new System.Drawing.Point(530, 68);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 35);
            this.label18.TabIndex = 19;
            this.label18.Text = "小計";
            // 
            // SUMCHANGE
            // 
            this.SUMCHANGE.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SUMCHANGE.Location = new System.Drawing.Point(605, 59);
            this.SUMCHANGE.Name = "SUMCHANGE";
            this.SUMCHANGE.Size = new System.Drawing.Size(264, 50);
            this.SUMCHANGE.TabIndex = 18;
            this.SUMCHANGE.TextChanged += new System.EventHandler(this.SUMCHANGE_TextChanged);
            // 
            // PRODUCTSTL
            // 
            this.PRODUCTSTL.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.PRODUCTSTL.Location = new System.Drawing.Point(425, 15);
            this.PRODUCTSTL.Name = "PRODUCTSTL";
            this.PRODUCTSTL.Size = new System.Drawing.Size(94, 39);
            this.PRODUCTSTL.TabIndex = 17;
            this.PRODUCTSTL.Text = "選擇";
            this.PRODUCTSTL.UseVisualStyleBackColor = true;
            this.PRODUCTSTL.Click += new System.EventHandler(this.PRODUCTSTL_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label16.Location = new System.Drawing.Point(40, 67);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 35);
            this.label16.TabIndex = 14;
            this.label16.Text = "數量";
            // 
            // AMTCHANGE
            // 
            this.AMTCHANGE.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.AMTCHANGE.Location = new System.Drawing.Point(115, 64);
            this.AMTCHANGE.MaxLength = 32;
            this.AMTCHANGE.Name = "AMTCHANGE";
            this.AMTCHANGE.Size = new System.Drawing.Size(303, 43);
            this.AMTCHANGE.TabIndex = 13;
            this.AMTCHANGE.TextChanged += new System.EventHandler(this.AMTCHANGE_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(40, 16);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(69, 35);
            this.label15.TabIndex = 12;
            this.label15.Text = "商品";
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox6.Location = new System.Drawing.Point(115, 13);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(303, 43);
            this.textBox6.TabIndex = 11;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(1245, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 31);
            this.label13.TabIndex = 12;
            this.label13.Text = "功能表";
            // 
            // NEW
            // 
            this.NEW.BackColor = System.Drawing.SystemColors.MenuBar;
            this.NEW.Font = new System.Drawing.Font("微軟正黑體", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NEW.Location = new System.Drawing.Point(1251, 37);
            this.NEW.Name = "NEW";
            this.NEW.Size = new System.Drawing.Size(170, 231);
            this.NEW.TabIndex = 13;
            this.NEW.Text = "新增\r\n訂單";
            this.NEW.UseVisualStyleBackColor = false;
            this.NEW.Click += new System.EventHandler(this.NEW_Click);
            // 
            // SAVE
            // 
            this.SAVE.BackColor = System.Drawing.SystemColors.MenuBar;
            this.SAVE.Font = new System.Drawing.Font("微軟正黑體", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.SAVE.Location = new System.Drawing.Point(1251, 274);
            this.SAVE.Name = "SAVE";
            this.SAVE.Size = new System.Drawing.Size(170, 231);
            this.SAVE.TabIndex = 14;
            this.SAVE.Text = "儲存\r\n訂單\r\n";
            this.SAVE.UseVisualStyleBackColor = false;
            this.SAVE.Click += new System.EventHandler(this.SAVE_Click);
            // 
            // DELETE
            // 
            this.DELETE.BackColor = System.Drawing.SystemColors.MenuBar;
            this.DELETE.Font = new System.Drawing.Font("微軟正黑體", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.DELETE.Location = new System.Drawing.Point(1251, 511);
            this.DELETE.Name = "DELETE";
            this.DELETE.Size = new System.Drawing.Size(170, 225);
            this.DELETE.TabIndex = 15;
            this.DELETE.Text = "刪除\r\n訂單";
            this.DELETE.UseVisualStyleBackColor = false;
            this.DELETE.Click += new System.EventHandler(this.DELETE_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(296, 349);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(110, 31);
            this.label14.TabIndex = 16;
            this.label14.Text = "訂單詳細";
            // 
            // NEWDETL
            // 
            this.NEWDETL.BackColor = System.Drawing.SystemColors.MenuBar;
            this.NEWDETL.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NEWDETL.Location = new System.Drawing.Point(412, 349);
            this.NEWDETL.Name = "NEWDETL";
            this.NEWDETL.Size = new System.Drawing.Size(226, 41);
            this.NEWDETL.TabIndex = 17;
            this.NEWDETL.Text = "新增細項";
            this.NEWDETL.UseVisualStyleBackColor = false;
            this.NEWDETL.Click += new System.EventHandler(this.NEWDETL_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Cornsilk;
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(19, 495);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(207, 57);
            this.button1.TabIndex = 31;
            this.button1.Text = "未完成交易訂單查詢";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.BTNSEARCH);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(19, 558);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(219, 371);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "其他查詢";
            // 
            // ORDERSYSTEM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1460, 989);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.NEWDETL);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.DELETE);
            this.Controls.Add(this.SAVE);
            this.Controls.Add(this.NEW);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LBORDER);
            this.Name = "ORDERSYSTEM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "訂單系統";
            this.Load += new System.EventHandler(this.ORDERSYSTEM_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LBORDER;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton RBOUTALL;
        private System.Windows.Forms.DateTimePicker dts;
        private System.Windows.Forms.DateTimePicker dtl;
        private System.Windows.Forms.RadioButton RBOUTNO;
        private System.Windows.Forms.RadioButton RBOUTAr;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton selectout;
        private System.Windows.Forms.RadioButton selectord;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton rbpayno;
        private System.Windows.Forms.RadioButton Rbpayar;
        private System.Windows.Forms.RadioButton Rbpayall;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BTNSEARCH;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TBID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button CusSTL;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TBORDERDATE;
        private System.Windows.Forms.TextBox TBTOTOL;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker DATAOUT;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox TBPHONE;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TBNAME;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button NEW;
        private System.Windows.Forms.Button SAVE;
        private System.Windows.Forms.Button DELETE;
        private System.Windows.Forms.Button PRODUCTSTL;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox AMTCHANGE;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox SUMCHANGE;
        private System.Windows.Forms.Button NEWDETL;
        private System.Windows.Forms.TextBox TBADRESS;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button TelDfl;
        private System.Windows.Forms.Button CellDfl;
        private System.Windows.Forms.TextBox TBCELL;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button AdressDfl;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button DELITEM;
        private System.Windows.Forms.CheckBox CBD;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.CheckBox CHEKPAY;
        private System.Windows.Forms.CheckBox CHEKOUT;
        private System.Windows.Forms.TextBox lastcrrect;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}