﻿namespace 期中專題
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BTN3 = new System.Windows.Forms.Button();
            this.BTN2 = new System.Windows.Forms.Button();
            this.BTN1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TBCELL = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TBADRESS = new System.Windows.Forms.TextBox();
            this.TBPHONE = new System.Windows.Forms.TextBox();
            this.TBNICKNAME = new System.Windows.Forms.TextBox();
            this.TBNAME = new System.Windows.Forms.TextBox();
            this.TBNUM = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LbResult = new System.Windows.Forms.ListBox();
            this.TBnicksearch = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TBNameSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.groupBox1.Controls.Add(this.BTN3);
            this.groupBox1.Controls.Add(this.BTN2);
            this.groupBox1.Controls.Add(this.BTN1);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(1038, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(180, 676);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "功能表";
            // 
            // BTN3
            // 
            this.BTN3.Location = new System.Drawing.Point(6, 547);
            this.BTN3.Name = "BTN3";
            this.BTN3.Size = new System.Drawing.Size(168, 107);
            this.BTN3.TabIndex = 10;
            this.BTN3.Text = "刪除客戶資料";
            this.BTN3.UseVisualStyleBackColor = true;
            this.BTN3.Click += new System.EventHandler(this.BTN3_Click);
            // 
            // BTN2
            // 
            this.BTN2.Location = new System.Drawing.Point(6, 294);
            this.BTN2.Name = "BTN2";
            this.BTN2.Size = new System.Drawing.Size(168, 247);
            this.BTN2.TabIndex = 9;
            this.BTN2.Text = "儲存客戶資料";
            this.BTN2.UseVisualStyleBackColor = true;
            this.BTN2.Click += new System.EventHandler(this.BTN2_Click);
            // 
            // BTN1
            // 
            this.BTN1.Location = new System.Drawing.Point(6, 41);
            this.BTN1.Name = "BTN1";
            this.BTN1.Size = new System.Drawing.Size(168, 247);
            this.BTN1.TabIndex = 8;
            this.BTN1.Text = "新增客戶";
            this.BTN1.UseVisualStyleBackColor = true;
            this.BTN1.Click += new System.EventHandler(this.BTN1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Turquoise;
            this.groupBox2.Controls.Add(this.TBCELL);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.TBADRESS);
            this.groupBox2.Controls.Add(this.TBPHONE);
            this.groupBox2.Controls.Add(this.TBNICKNAME);
            this.groupBox2.Controls.Add(this.TBNAME);
            this.groupBox2.Controls.Add(this.TBNUM);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Font = new System.Drawing.Font("微軟正黑體", 26.25F);
            this.groupBox2.Location = new System.Drawing.Point(360, 41);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(672, 675);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "資料欄位";
            // 
            // TBCELL
            // 
            this.TBCELL.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBCELL.Location = new System.Drawing.Point(173, 433);
            this.TBCELL.Name = "TBCELL";
            this.TBCELL.Size = new System.Drawing.Size(346, 57);
            this.TBCELL.TabIndex = 23;
            this.TBCELL.TextChanged += new System.EventHandler(this.TBCELL_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 438);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 44);
            this.label8.TabIndex = 22;
            this.label8.Text = "手機";
            // 
            // TBADRESS
            // 
            this.TBADRESS.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBADRESS.Location = new System.Drawing.Point(173, 529);
            this.TBADRESS.Multiline = true;
            this.TBADRESS.Name = "TBADRESS";
            this.TBADRESS.Size = new System.Drawing.Size(493, 133);
            this.TBADRESS.TabIndex = 21;
            this.TBADRESS.TextChanged += new System.EventHandler(this.TBADRESS_TextChanged);
            // 
            // TBPHONE
            // 
            this.TBPHONE.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBPHONE.Location = new System.Drawing.Point(173, 337);
            this.TBPHONE.Name = "TBPHONE";
            this.TBPHONE.Size = new System.Drawing.Size(346, 57);
            this.TBPHONE.TabIndex = 20;
            this.TBPHONE.TextChanged += new System.EventHandler(this.TBPHONE_TextChanged);
            // 
            // TBNICKNAME
            // 
            this.TBNICKNAME.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBNICKNAME.Location = new System.Drawing.Point(173, 241);
            this.TBNICKNAME.Name = "TBNICKNAME";
            this.TBNICKNAME.Size = new System.Drawing.Size(246, 57);
            this.TBNICKNAME.TabIndex = 19;
            this.TBNICKNAME.TextChanged += new System.EventHandler(this.TBNICKNAME_TextChanged);
            // 
            // TBNAME
            // 
            this.TBNAME.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBNAME.Location = new System.Drawing.Point(173, 145);
            this.TBNAME.Name = "TBNAME";
            this.TBNAME.Size = new System.Drawing.Size(246, 57);
            this.TBNAME.TabIndex = 18;
            this.TBNAME.TextChanged += new System.EventHandler(this.TBNAME_TextChanged);
            // 
            // TBNUM
            // 
            this.TBNUM.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBNUM.Location = new System.Drawing.Point(173, 49);
            this.TBNUM.Name = "TBNUM";
            this.TBNUM.ReadOnly = true;
            this.TBNUM.Size = new System.Drawing.Size(246, 57);
            this.TBNUM.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 534);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 44);
            this.label7.TabIndex = 4;
            this.label7.Text = "地址";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 44);
            this.label6.TabIndex = 3;
            this.label6.Text = "電話";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 246);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 44);
            this.label5.TabIndex = 2;
            this.label5.Text = "暱稱";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 44);
            this.label4.TabIndex = 1;
            this.label4.Text = "姓名";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(160, 44);
            this.label3.TabIndex = 0;
            this.label3.Text = "客戶編號";
            // 
            // LbResult
            // 
            this.LbResult.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LbResult.FormattingEnabled = true;
            this.LbResult.ItemHeight = 24;
            this.LbResult.Location = new System.Drawing.Point(213, 88);
            this.LbResult.Name = "LbResult";
            this.LbResult.Size = new System.Drawing.Size(141, 628);
            this.LbResult.TabIndex = 2;
            this.LbResult.SelectedIndexChanged += new System.EventHandler(this.LbResult_SelectedIndexChanged);
            // 
            // TBnicksearch
            // 
            this.TBnicksearch.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBnicksearch.Location = new System.Drawing.Point(40, 192);
            this.TBnicksearch.Name = "TBnicksearch";
            this.TBnicksearch.Size = new System.Drawing.Size(167, 57);
            this.TBnicksearch.TabIndex = 18;
            this.TBnicksearch.TextChanged += new System.EventHandler(this.TBnicksearch_TextChanged);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(39, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 43);
            this.label2.TabIndex = 17;
            this.label2.Text = "暱稱搜尋";
            // 
            // TBNameSearch
            // 
            this.TBNameSearch.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBNameSearch.Location = new System.Drawing.Point(40, 88);
            this.TBNameSearch.Name = "TBNameSearch";
            this.TBNameSearch.Size = new System.Drawing.Size(167, 57);
            this.TBNameSearch.TabIndex = 16;
            this.TBNameSearch.TextChanged += new System.EventHandler(this.TBNameSearch_TextChanged);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(39, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 43);
            this.label1.TabIndex = 15;
            this.label1.Text = "姓名搜尋";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(205, 42);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 43);
            this.label9.TabIndex = 19;
            this.label9.Text = "結果";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(40, 255);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(167, 65);
            this.button1.TabIndex = 20;
            this.button1.Text = "重新整理";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.ClientSize = new System.Drawing.Size(1259, 760);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TBnicksearch);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TBNameSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LbResult);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "客戶管理系統";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox LbResult;
        private System.Windows.Forms.Button BTN1;
        private System.Windows.Forms.Button BTN3;
        private System.Windows.Forms.Button BTN2;
        private System.Windows.Forms.TextBox TBnicksearch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TBNameSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBADRESS;
        private System.Windows.Forms.TextBox TBPHONE;
        private System.Windows.Forms.TextBox TBNICKNAME;
        private System.Windows.Forms.TextBox TBNAME;
        private System.Windows.Forms.TextBox TBNUM;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TBCELL;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button1;
    }
}