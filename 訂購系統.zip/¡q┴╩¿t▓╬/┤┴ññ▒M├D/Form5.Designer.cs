﻿namespace 期中專題
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.TB2 = new System.Windows.Forms.TextBox();
            this.TB1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TB3 = new System.Windows.Forms.TextBox();
            this.DT1 = new System.Windows.Forms.DateTimePicker();
            this.DT2 = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.LBM = new System.Windows.Forms.Label();
            this.LBS = new System.Windows.Forms.Label();
            this.TBSEARCH = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label12 = new System.Windows.Forms.Label();
            this.DT6 = new System.Windows.Forms.DateTimePicker();
            this.DT5 = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "年統計";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "月統計";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 31);
            this.label4.TabIndex = 3;
            this.label4.Text = "範圍統計";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 31);
            this.label3.TabIndex = 4;
            this.label3.Text = "客戶統計";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Info;
            this.button1.Location = new System.Drawing.Point(658, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 39);
            this.button1.TabIndex = 5;
            this.button1.Text = "查詢";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Info;
            this.button2.Location = new System.Drawing.Point(658, 278);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 39);
            this.button2.TabIndex = 6;
            this.button2.Text = "查詢";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Info;
            this.button3.Location = new System.Drawing.Point(658, 181);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 39);
            this.button3.TabIndex = 7;
            this.button3.Text = "查詢";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Info;
            this.button4.Location = new System.Drawing.Point(658, 101);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 39);
            this.button4.TabIndex = 8;
            this.button4.Text = "查詢";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // TB2
            // 
            this.TB2.Location = new System.Drawing.Point(133, 98);
            this.TB2.MaxLength = 10;
            this.TB2.Name = "TB2";
            this.TB2.Size = new System.Drawing.Size(86, 39);
            this.TB2.TabIndex = 10;
            this.TB2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TB2.TextChanged += new System.EventHandler(this.TB2_TextChanged);
            // 
            // TB1
            // 
            this.TB1.Location = new System.Drawing.Point(133, 14);
            this.TB1.MaxLength = 10;
            this.TB1.Name = "TB1";
            this.TB1.Size = new System.Drawing.Size(86, 39);
            this.TB1.TabIndex = 11;
            this.TB1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TB1.TextChanged += new System.EventHandler(this.TB1_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(235, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 31);
            this.label5.TabIndex = 12;
            this.label5.Text = "年";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(235, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 31);
            this.label6.TabIndex = 14;
            this.label6.Text = "年";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(371, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 31);
            this.label7.TabIndex = 17;
            this.label7.Text = "月";
            // 
            // TB3
            // 
            this.TB3.Location = new System.Drawing.Point(279, 98);
            this.TB3.MaxLength = 10;
            this.TB3.Name = "TB3";
            this.TB3.Size = new System.Drawing.Size(86, 39);
            this.TB3.TabIndex = 16;
            this.TB3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TB3.TextChanged += new System.EventHandler(this.TB3_TextChanged);
            // 
            // DT1
            // 
            this.DT1.Location = new System.Drawing.Point(133, 179);
            this.DT1.Name = "DT1";
            this.DT1.Size = new System.Drawing.Size(200, 39);
            this.DT1.TabIndex = 18;
            this.DT1.ValueChanged += new System.EventHandler(this.DT1_ValueChanged);
            // 
            // DT2
            // 
            this.DT2.Location = new System.Drawing.Point(383, 179);
            this.DT2.Name = "DT2";
            this.DT2.Size = new System.Drawing.Size(200, 39);
            this.DT2.TabIndex = 19;
            this.DT2.ValueChanged += new System.EventHandler(this.DT2_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(339, 181);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 31);
            this.label8.TabIndex = 20;
            this.label8.Text = "至";
            // 
            // LBM
            // 
            this.LBM.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.LBM.Location = new System.Drawing.Point(652, 447);
            this.LBM.Name = "LBM";
            this.LBM.Size = new System.Drawing.Size(299, 66);
            this.LBM.TabIndex = 22;
            this.LBM.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LBS
            // 
            this.LBS.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.LBS.Location = new System.Drawing.Point(652, 367);
            this.LBS.Name = "LBS";
            this.LBS.Size = new System.Drawing.Size(299, 66);
            this.LBS.TabIndex = 21;
            this.LBS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TBSEARCH
            // 
            this.TBSEARCH.Location = new System.Drawing.Point(17, 338);
            this.TBSEARCH.Name = "TBSEARCH";
            this.TBSEARCH.Size = new System.Drawing.Size(110, 39);
            this.TBSEARCH.TabIndex = 23;
            this.TBSEARCH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TBSEARCH.TextChanged += new System.EventHandler(this.TBSEARCH_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(17, 304);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 31);
            this.label11.TabIndex = 24;
            this.label11.Text = "搜尋";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 31;
            this.listBox1.Location = new System.Drawing.Point(133, 246);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(121, 469);
            this.listBox1.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(140, 118);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 31);
            this.label12.TabIndex = 29;
            this.label12.Text = "至";
            // 
            // DT6
            // 
            this.DT6.Location = new System.Drawing.Point(74, 163);
            this.DT6.Name = "DT6";
            this.DT6.Size = new System.Drawing.Size(200, 39);
            this.DT6.TabIndex = 28;
            this.DT6.ValueChanged += new System.EventHandler(this.DT6_ValueChanged);
            // 
            // DT5
            // 
            this.DT5.Location = new System.Drawing.Point(74, 60);
            this.DT5.Name = "DT5";
            this.DT5.Size = new System.Drawing.Size(200, 39);
            this.DT5.TabIndex = 27;
            this.DT5.ValueChanged += new System.EventHandler(this.DT5_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 66);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 31);
            this.label13.TabIndex = 26;
            this.label13.Text = "範圍";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label14.Location = new System.Drawing.Point(15, 56);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(987, 2);
            this.label14.TabIndex = 30;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label15.Location = new System.Drawing.Point(15, 141);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(987, 2);
            this.label15.TabIndex = 31;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label16.Location = new System.Drawing.Point(15, 221);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(987, 2);
            this.label16.TabIndex = 32;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(49, 19);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(129, 35);
            this.checkBox1.TabIndex = 33;
            this.checkBox1.Text = "日期範圍";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.DT6);
            this.panel1.Controls.Add(this.DT5);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Location = new System.Drawing.Point(260, 246);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(309, 238);
            this.panel1.TabIndex = 34;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1011, 769);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.TBSEARCH);
            this.Controls.Add(this.LBM);
            this.Controls.Add(this.LBS);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.DT2);
            this.Controls.Add(this.DT1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TB3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TB1);
            this.Controls.Add(this.TB2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "統計";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox TB2;
        private System.Windows.Forms.TextBox TB1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TB3;
        private System.Windows.Forms.DateTimePicker DT1;
        private System.Windows.Forms.DateTimePicker DT2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label LBM;
        private System.Windows.Forms.Label LBS;
        private System.Windows.Forms.TextBox TBSEARCH;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DateTimePicker DT6;
        private System.Windows.Forms.DateTimePicker DT5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel1;
    }
}